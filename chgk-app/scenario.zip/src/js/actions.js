function enter_answer(answer, context) {
    addAction({
        type: "enter_answer",
        answer: answer
    }, context);
}

function check_answer(answer, context) {
    addAction({
        type: "check_answer",
        answer: answer
    }, context);
}

function next_question(context) {
    addAction({
        type: "next_question"
    }, context);
}